# Definindo os preços dos ovos, recheios e adicionais
preco_ovos = {"pequeno": 7.80, "medio": 12.90, "grande": 23.95}
preco_recheios = {"chocolate preto": 9.67, "chocolate branco": 4.50, "chocolate ao leite": 9.32}
preco_adicionais = {"KitKat": 4.67, "MM'S": 5.43}

# Recebendo as escolhas do cliente
tamanho = input("Escolha o tamanho do ovo (pequeno, medio ou grande): ")
recheio1 = input("Escolha o primeiro recheio (chocolate preto, chocolate branco ou chocolate ao leite): ")
recheio2 = input("Escolha o segundo recheio (ou deixe em branco se não quiser escolher outro recheio): ")
presente = input("O ovo será para presente? (sim ou nao): ")
entrega = input("O ovo será entregue? (sim ou nao): ")
forma_pagamento = input("Escolha a forma de pagamento (cartao de credito, dinheiro ou pix): ")
quantidade = int(input("Escolha a quantidade de ovos: "))

# Calculando o valor do ovo
preco_total += preco_ovos[tamanho]
preco_total += preco_recheios[recheio1]
if recheio2:
    preco_total += preco_recheios[recheio2] / 2
if presente == "sim":
    preco_total += 2.50
if entrega == "sim":
    preco_total += 5.00
for adicional in preco_adicionais.values():
    if input(f"Adicionar {adicional}? (sim ou nao): ") == "sim":
        preco_total += adicional
preco_total *= quantidade
if forma_pagamento == "cartao de credito":
    preco_total += 3.30
elif forma_pagamento in ["dinheiro", "pix"]:
    preco_total *= 0.9

# Exibindo o valor total
print(f"O valor total é: R${preco_total:.2f}")




        